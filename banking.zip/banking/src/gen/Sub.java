package gen;

public class Sub {
private int a;
public static int n;
public Sub(){}
public Sub(int a) {
	super();
	this.a = a;
	n++;
}
public int getA() {
	return a;
}
public void setA(int a) {
	this.a = a;
}


}
