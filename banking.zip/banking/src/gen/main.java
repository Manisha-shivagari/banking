package gen;

public class main {

	public static void main(String[] args) {
	Sub sub=new Sub(1);
	System.out.println(Sub.n+" " +sub.getA());
	Sub sub1=new Sub(6);
	System.out.println(Sub.n+" "+sub1.getA());

	}

}
