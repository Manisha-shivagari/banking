package com.cg.banking.main;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class Mainclass {

	public static void main(String[] args) {
		
		
		
	}
}
		/*Transaction[] transactions=new Transaction[3];
		transactions[0]=new Transaction(2345, 90000, "savings");
		transactions[1]=new Transaction(3345, 70000, "loan");
		transactions[2]=new Transaction(5345, 60000, "savings");
		
		Account[] accounts=new Account[2];
		accounts[0]=new Account(123, 10, 3000, "offline", "pune", "phonepe", "success",transactions);
		accounts[1]=new Account(124, 20, 4000, "online", "hyd", "tez", "not success",transactions);
   		
		Customer[] customers=new Customer[2];
		customers[0]=new Customer(123l, 456l, 67788l,7888l,  "mni", "ki", "jhhgh", "uuiii", new Address(0, "pune", "hyd", "india", "juhy", "jugt"),new Address(0, "hyd", "delhi", "hyy", "uytr", "ugrr"),accounts);
		customers[1]=new Customer(124l, 456l, 67788l,7888l,  "mni", "ki", "jhhgh", "uuiii", new Address(0, "pune", "hyd", "india", "juhy", "jugt"),new Address(0, "hyd", "delhi", "hyy", "uytr", "ugrr"),accounts);
		
	System.out.println(customers[1].getAccounts()[0].getTransactions()[0].getAccountType());
		
	
	}
}*/