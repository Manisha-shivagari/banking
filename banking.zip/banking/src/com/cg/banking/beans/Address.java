package com.cg.banking.beans;

public class Address {
	private int pinCode;
	private String  city,state,country,localAddress,homeAddress; 
	public Address(){}
	public Address(int pinCode, String city, String state, String country, String localAddress, String homeAddress) {
		super();
		this.pinCode = pinCode;
		this.city = city;
		this.state = state;
		this.country = country;
		this.localAddress = localAddress;
		this.homeAddress = homeAddress;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getLocalAddress() {
		return localAddress;
	}
	public void setLocalAddress(String localAddress) {
		this.localAddress = localAddress;
	}
	public String getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(String homeAddress) {
		this.homeAddress = homeAddress;
	}
	
}
