package com.cg.banking.beans;

public class Account {
	private int transactionId, timeStamp, amount ,pinNumber,accountNo;
	private String transactionType, transactionLocation, 	modeOfTransation, transactionStatus;
	private Transaction[] transactions;
	private static int tCounter=10;
	public Account(){}
	public Account(int transactionId, int timeStamp, int amount, String transactionType, String transactionLocation,
			String modeOfTransation, String transactionStatus, int accountNo,Transaction[] transactions) {
		super();
		this.transactionId = transactionId;
		this.timeStamp = timeStamp;
		this.amount = amount;
		this.transactionType = transactionType;
		this.transactionLocation = transactionLocation;
		this.modeOfTransation = modeOfTransation;
		this.transactionStatus = transactionStatus;
		this.transactions = transactions;
		this.accountNo=accountNo;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(int timeStamp) {
		this.timeStamp = timeStamp;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTransactionLocation() {
		return transactionLocation;
	}
	public void setTransactionLocation(String transactionLocation) {
		this.transactionLocation = transactionLocation;
	}
	public String getModeOfTransation() {
		return modeOfTransation;
	}
	public void setModeOfTransation(String modeOfTransation) {
		this.modeOfTransation = modeOfTransation;
	}
	public String getTransactionStatus() {
		return transactionStatus;
	}
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}
	public Transaction[] getTransactions() {
		return transactions;
	}
	public void setTransactions(Transaction[] transactions) {
		this.transactions = transactions;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo=accountNo;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber=pinNumber;
	}
	public int getPinNumber() {
		return pinNumber;
	}
	public int getTCounter() {
		return tCounter;
	}
	public void setTCounter(int tCounter) {
		this.tCounter = tCounter;
	}
}
