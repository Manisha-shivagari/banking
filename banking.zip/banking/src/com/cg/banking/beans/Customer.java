package com.cg.banking.beans;

public class Customer {
			private long customerId,mobileNo,adharNo,dateOfBirth;
			private String firstName,lastName,emailId,pancardNo;
			private  Address localAddress,homeAddress; 
			private Account[] accounts;
			private int accountIdCounter=100;
			private int accountIdxCounter=0;
			private static int tCounter=10;
			
					    public Customer(){}
						public Customer(long customerId, long mobileNo, long adharNo, long dateOfBirth,
								String firstName, String lastName, String emailId, String pancardNo,
								Address localAddress, Address homeAddress, Account[] accounts)
							{
							super();
							this.customerId = customerId;
							this.mobileNo = mobileNo;
							this.adharNo = adharNo;
							this.dateOfBirth = dateOfBirth;
							this.firstName = firstName;
							this.lastName = lastName;
							this.emailId = emailId;
							this.pancardNo = pancardNo;
							this.localAddress = localAddress;
							this.homeAddress = homeAddress;
							this.accounts = accounts;
							
						}
						public long getCustomerId() {
							return customerId;
						}
						public void setCustomerId(long customerId) {
							this.customerId = customerId;
						}
						public long getMobileNo() {
							return mobileNo;
						}
						public void setMobileNo(long mobileNo) {
							this.mobileNo = mobileNo;
						}
						public long getAdharNo() {
							return adharNo;
						}
						public void setAdharNo(long adharNo) {
							this.adharNo = adharNo;
						}
						public long getDateOfBirth() {
							return dateOfBirth;
						}
						public void setDateOfBirth(long dateOfBirth) {
							this.dateOfBirth = dateOfBirth;
						}
						public String getFirstName() {
							return firstName;
						}
						public void setFirstName(String firstName) {
							this.firstName = firstName;
						}
						public String getLastName() {
							return lastName;
						}
						public void setLastName(String lastName) {
							this.lastName = lastName;
						}
						public String getEmailId() {
							return emailId;
						}
						public void setEmailId(String emailId) {
							this.emailId = emailId;
						}
						public String getPancardNo() {
							return pancardNo;
						}
						public void setPancardNo(String pancardNo) {
							this.pancardNo = pancardNo;
						}
						public Address getLocalAddress() {
							return localAddress;
						}
						public void setLocalAddress(Address localAddress) {
							this.localAddress = localAddress;
						}
						public Address getHomeAddress() {
							return homeAddress;
						}
						public void setHomeAddress(Address homeAddress) {
							this.homeAddress = homeAddress;
						}
						public Account[] getAccounts() {
							return accounts;
						}
						public void setAccounts(Account[] accounts) {
							this.accounts = accounts;
						}
						public int getAccountIdCounter() {
							return accountIdCounter;
						}
						public void setAccountIdCounter(int accountIdCounter) {
							this.accountIdCounter = accountIdCounter;
						}
						public int getAccountIdxCounter() {
							return accountIdxCounter;
						}
						public void setAccountIdxCounter(int accountIdxCounter) {
							this.accountIdxCounter = accountIdxCounter;
						}
						public int getTCounter() {
							return tCounter;
						}
						public void setTCounter(int tCounter) {
							this.tCounter = tCounter;
						}
						
}